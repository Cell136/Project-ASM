﻿namespace Project.Models.ViewModel
{
    public class ViewModelDetailJob
    {
        public Job job { get; set; }
        public List<Job> JobList { get; set;}
    }
}
