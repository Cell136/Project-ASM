﻿namespace Project.Models.ViewModel
{
    public class ViewModelJobAndCV
    {
        public List<Job> job {  get; set; }
        public List<JobApplication> jobApplication { get; set; }
    }
}
